import 'package:geolocator/geolocator.dart';

class GeolocatorService{
  final Geolocator geo = Geolocator();

  Stream<Position> getCurrentLocation(){
    print('Before getStream');
    return Geolocator.getPositionStream();
  }

  Future<Position> getInitialLocation() async{
    return Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }
}